package com.cts.grizzly.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.grizzly.bean.Product;
import com.cts.grizzly.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService productService;
	@RequestMapping(value="viewProduct.html",method=RequestMethod.GET)
	public ModelAndView getAllProducts(){
		ModelAndView modelAndView=new ModelAndView();
		List<Product> result=productService.getAllProducts();
		modelAndView.addObject("list", result);
		modelAndView.setViewName("viewProduct");
		return modelAndView;
	}
	@RequestMapping(value="product.html", method=RequestMethod.POST)
	public ModelAndView addProduct(@ModelAttribute Product product){
		ModelAndView modelAndview = new ModelAndView();
		
		String result = productService.addProduct(product);
		
		if("success".equals(result)){
			modelAndview.addObject("product", product);
			modelAndview.setViewName("productAdded");
		}
		else {
			modelAndview.setViewName("errorView");
		}
		
		return modelAndview;
	}
	
	@RequestMapping(value="product.html", method=RequestMethod.GET)
	public String addProductView()
	{
		return "product";
	}
}
