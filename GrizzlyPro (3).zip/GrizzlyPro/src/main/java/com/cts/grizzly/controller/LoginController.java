package com.cts.grizzly.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cts.grizzly.bean.Login;
import com.cts.grizzly.service.LoginService;

@Controller
public class LoginController {
	@RequestMapping("login.html")
	public String getLoginPage(){
		return "login";
	}
	
	@Autowired
	LoginService loginService;
	
	@RequestMapping(value="login.html", method=RequestMethod.POST)
	public ModelAndView validateUser(@ModelAttribute Login login, HttpSession session){
		ModelAndView modelAndView = new ModelAndView();
		if(loginService.authentication(login)){
			modelAndView.setViewName("adminPage");
			return modelAndView;
		} else{
			modelAndView.addObject("login",login);
			
			session.setAttribute("login", login);
			modelAndView.setViewName("index");
		}
		return modelAndView;
	}
}
